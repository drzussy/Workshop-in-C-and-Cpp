## Using Test Files in Ex4: A Quick Guide

##### Files Structure

```bash
.
├── CMakeLists.txt
├── README.md
├── api # your code goes here.
│   ├── Activation.cpp
│   ├── Activation.h
│   ├── Dense.cpp
│   ├── Dense.h
│   ├── Matrix.cpp
│   ├── Matrix.h
│   ├── MlpNetwork.cpp
│   └── MlpNetwork.h
├── assets # pre-submit files (DON'T CHANGE!)
│   ├── TestAST_1.info
│   ├── TestAST_1.match
│   ├── TestAST_1.res
│   ├── presubmit.inb1
│   ├── presubmit.inb2
│   ├── presubmit.inb3
│   ├── presubmit.inb4
│   ├── presubmit.inim0
│   ├── presubmit.inw1
│   ├── presubmit.inw2
│   ├── presubmit.inw3
│   └── presubmit.inw4
├── cmake-build-debug
├── main.cpp # pre-submit test
├── oh_tests_exceptions.cpp # Oryan test
└── plot_img.py
```

##### Usage

To use the provided test files, follow these steps:

1. Import the following files into the api folder of your project:
    - `Matrix.h`
    - `Matrix.cpp`
    - `Activation.h`
    - `Activation.cpp`
    - `Dense.h`
    - `Dense.cpp`
    - `MlpNetwork.h`
    - `MlpNetwork.cpp`
2. Run the desired tests:
    - _Pre-submit Test_:
        - Comment out the _main_ function inside `oh_tests_exceptions.cpp`.
        - Compile and run the program.
    - _Oryan's Test_:
        - Comment out the _main_ function inside `main.cpp`.
        - Compile and run the program.

Enjoy testing your code using the provided test files!

Note: Make sure to preserve the directory structure and keep the necessary files in the respective folders as indicated
above.